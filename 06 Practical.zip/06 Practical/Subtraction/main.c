#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Subtraction\n");
    int a, b, sub;
    a=10;
    b=5;
    sub=a-b;
    printf("%d",sub);

    return 0;
}
