#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{

    printf("Array Data Deletion : \n");
    int a[10],k,i,j,n,item;
    printf("\nEnter how many elements in the array(<10) : \t");
    scanf("%d",&n);
    printf("\n input %d integers : ",n);

    for(i=0; i<n; i++)
        scanf("%d",&a[i]);
    printf("\nOriginal array contains ......");
    for(i=0; i<n;i++)
        scanf("\n Array [%d] = %d",i,a[i]);
    printf("\n\n To delete an element......");
    printf("\n Enter which array position : ");
    scanf("% d",&k);
    item = a[k];
    for(j=k;j<=n-1;j++)
        a[j]=a[j+1];
    n=n-1;

    printf("\n\n After delete the element (%d) \n", item);
    printf("The array Contains .......");
    for(i=0; i<n; i++)
        printf("\n Array [%d] = %d",i,a[i]);
    getch();

    return 0;
}
