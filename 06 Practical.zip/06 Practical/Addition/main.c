#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Addition\n");

    int a, b, sum;
    a=5;
    b=10;
    sum=a+b;

    printf("%d",sum);

    return 0;
}
