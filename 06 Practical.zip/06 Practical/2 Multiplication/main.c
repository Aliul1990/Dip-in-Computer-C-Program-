#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define rows 2
#define columns 2

void main()
{
    int m1column=2,m2row=2;
    int product[rows][columns],matrix1[rows][2]={1,2,3,4}, matrix2[2][columns]={7,8,9,10};
    int i,j,k;
//    clrscr.();
    printf("First matrix\n");
    for(i=0;i<rows;i++){
        for(j=0;j<2;j++){
            printf("%4d",matrix1[i][j]);
        }
        printf("\n");
    }
    printf("\nSecond matrix\n");
    for(i=0;i<2;i++){
        for(j=0;j<columns;j++){
            printf("%4d",matrix2[i][j]);
        }
        printf("\n");
    }

//product fill with 0
    for(i=0;i<2;i++){
        for(j=0;j<columns;j++){
            product[i][j]=0;
        }
    }

    printf("Multiplication Tables\n\n");

        for(i=0;i<rows;i++){
            for(j=0;j<columns;j++){
               for(k=0;k<m1column;k++){//m2row
                    product[i][j]=product[i][j]+(matrix1[i][k]*matrix2[k][j]);

               }
               //product[l][i]=line;
                printf("%4d",product[i][j]);
               //line=0;
            }
            printf("\n");
        }
printf("\nProduct of matrix\n");
    for(i=0;i<2;i++){
        for(j=0;j<columns;j++){
            printf("%4d",product[i][j]);
        }
        printf("\n");
    }

    getch();
}
