#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Division :\n");
    int a,b,div;
    a=10;
    b=5;
    div=a/b;
    printf("%d",div);

    return 0;
}
