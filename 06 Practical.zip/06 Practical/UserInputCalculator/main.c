#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <conio.h>

int main()
{
    printf("User Input Calculator :\n");
    int a,b,result;
    printf("Please Enter your First Number :");
    scanf("%d",&a);

    printf("Please Enter your 2nd Number :");
    scanf("%d",&b);

    result=a+b;
    printf("First and 2nd Number Calculator :%d\n\n",result);
    getch();

    return 0;
}
