#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Multiplication :\n");
    int a,b,mul;
    a=5;
    b=10;
    mul=a*b;
    printf("%d",mul);

    return 0;
}
