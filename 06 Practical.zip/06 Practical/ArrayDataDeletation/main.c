#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
int main(){

   int a[10], k,i,j,n,item;
   printf("\nEnter how many elements in the array");

    getch();
    return 0;
}
