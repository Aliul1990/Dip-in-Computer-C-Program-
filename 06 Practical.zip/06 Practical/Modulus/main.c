#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Modulus :\n");
    int a,b,mod;
    a=11;
    b=5;
    mod=a%b;
    printf("%d",mod);
    return 0;
}
