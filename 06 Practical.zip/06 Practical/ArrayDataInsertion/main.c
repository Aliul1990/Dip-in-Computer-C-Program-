#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{
    printf("Array Data Insertion : \n");
    int array[100]={4,6,7,9,8,2};
    printf("\nOrginal Array Contains........");
    for(int i=0;i<=5;i++){
         printf("\n Array [%d]=%d",i,array[i]);
    }

    printf("\n\n");
    int UpperIndex=5;
    int copyUpperIndex;
    copyUpperIndex=UpperIndex;
    int insertItemValue=5;
    int InsetIndex=0;

    while(copyUpperIndex>=InsetIndex){
        array[copyUpperIndex+1]=array[copyUpperIndex];
        copyUpperIndex=copyUpperIndex-1;
    }

    array[InsetIndex]=insertItemValue;
    UpperIndex=UpperIndex+1;
    printf("\nAfter new inserting the array contains.");
    for(int i=0;i<=UpperIndex; i++){
        printf("\nArray [%d]=%d",i,array[i]);
    }

    getch();
    return 0;
}
