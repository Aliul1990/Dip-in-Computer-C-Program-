#include <stdio.h>
#include <stdlib.h>
#define aliul main

int aliul()
{
    printf("Function Call in Main() \n");
sum();
    return 0;
}

int sum(){
    int a,b,sum;
    a=5;
    b=10;
    sum=a+b;
    printf("%d",sum);
return 0;
}
