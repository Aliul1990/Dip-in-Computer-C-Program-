#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf(" Personal Information :\n ====================\n Name    : Md. Aliul Islam \n Phone   : 01518317509 \n Address : Dhaka-1205");
    return 0;
}
